package com.tutorialesprogramacionya.proyecto002;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private EditText et1;
    private EditText et2;
    private TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1=findViewById(R.id.et1);
        et2=findViewById(R.id.et2);
        tv1=findViewById(R.id.tv1);
    }

    //Este método se ejecutará cuando se presione el botón
    public void Comparar(View view) {
        if (Objects.equals(et1.getText().toString(), et2.getText().toString())) {
            tv1.setText("Los textos ingresados coinciden");
        } else {
            tv1.setText("Los textos ingresados no coinciden");
        }
    }

}